-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 05, 2023 at 03:47 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `a_zadaltybat`
--

-- --------------------------------------------------------

--
-- Table structure for table `app_menus`
--

CREATE TABLE `app_menus` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `type` enum('side','user','cart') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postion` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `app_menus`
--

INSERT INTO `app_menus` (`id`, `type`, `postion`, `created_at`, `updated_at`) VALUES
(1, 'user', 0, '2023-10-10 10:01:45', '2023-10-10 10:01:45'),
(2, 'cart', 0, '2023-10-10 10:01:45', '2023-10-10 10:01:45'),
(3, 'side', 3, '2023-10-10 10:10:42', '2023-10-10 10:13:09'),
(4, 'side', 2, '2023-10-10 10:11:16', '2023-10-10 10:13:09'),
(5, 'side', 1, '2023-10-10 10:12:11', '2023-10-10 10:13:06');

-- --------------------------------------------------------

--
-- Table structure for table `app_menu_translations`
--

CREATE TABLE `app_menu_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `menu_id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` int(11) DEFAULT NULL,
  `title` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `app_menu_translations`
--

INSERT INTO `app_menu_translations` (`id`, `menu_id`, `locale`, `url`, `label`, `icon`, `title`) VALUES
(1, 2, 'ar', 'https://freestyle4u.net/et8/public/EtmanShop/CartView/?mobile=1', 'السلة', 60562, 1),
(2, 1, 'ar', 'https://freestyle4u.net/et8/public/EtmanShop/profile/?mobile=1', 'الملف الشخصي', 58519, 1),
(3, 3, 'ar', 'https://freestyle4u.net/et8/public/%D8%A7%D8%AA%D8%B5%D9%84-%D8%A8%D9%86%D8%A7/?mobile=1', 'اتصل بنا', 57738, 1),
(4, 4, 'ar', 'https://freestyle4u.net/et8/public/EtmanShop/%D8%B9%D8%B1%D9%88%D8%B6-%D8%AA%D8%AC%D8%A7%D8%B1-%D8%A7%D9%84%D8%AC%D9%85%D9%84%D8%A9/?mobile=1', 'عروض الجمله', 61828, 1),
(5, 5, 'ar', 'https://freestyle4u.net/et8/public/EtmanShop//?mobile=1', 'الرئيسية', 58519, 1);

-- --------------------------------------------------------

--
-- Table structure for table `app_settings`
--

CREATE TABLE `app_settings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `baseUrl` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobilePrefix` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `prefix` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SideLogo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `AppName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ColorDark` bigint(20) DEFAULT NULL,
  `ColorLight` bigint(20) DEFAULT NULL,
  `AppBarIconColor` bigint(20) DEFAULT NULL,
  `BackGroundColor` bigint(20) DEFAULT NULL,
  `SplashColor` bigint(20) DEFAULT NULL,
  `PreloadingColor` bigint(20) DEFAULT NULL,
  `StatueBArColor` bigint(20) DEFAULT NULL,
  `AppBarColor` bigint(20) DEFAULT NULL,
  `AppBarColorText` bigint(20) DEFAULT NULL,
  `sideMenuText` bigint(20) DEFAULT NULL,
  `sideMenuColor` bigint(20) DEFAULT NULL,
  `mainScreenScale` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sideMenuAngle` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sideMenuStyle` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `AppTheme` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `facebook` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `youtube` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `instagram` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `linkedin` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `whatsAppNumber` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `whatsAppMessage` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `whatsAppKey` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telegram_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telegram_group` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telegram_phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `app_settings`
--

INSERT INTO `app_settings` (`id`, `status`, `baseUrl`, `mobilePrefix`, `prefix`, `logo`, `SideLogo`, `AppName`, `ColorDark`, `ColorLight`, `AppBarIconColor`, `BackGroundColor`, `SplashColor`, `PreloadingColor`, `StatueBArColor`, `AppBarColor`, `AppBarColorText`, `sideMenuText`, `sideMenuColor`, `mainScreenScale`, `sideMenuAngle`, `sideMenuStyle`, `AppTheme`, `facebook`, `twitter`, `youtube`, `instagram`, `linkedin`, `whatsAppNumber`, `whatsAppMessage`, `whatsAppKey`, `telegram_key`, `telegram_group`, `telegram_phone`, `created_at`, `updated_at`) VALUES
(1, 1, 'https://freestyle4u.net/et8/public/', 'EtmanShop/', '?mobile=1', NULL, NULL, 'عتمان جروب', 4292621637, 4293283920, 4278190080, 4294967295, 4278190080, 4293283920, 4293283920, 4278190080, 4278190080, 4278190080, 4293283920, '-0.1', '0', 'style3', 'home', 'https://www.facebook.com/Etman.Group', NULL, 'https://www.youtube.com/channel/UC8GkiBf6L9bogsUtx0PEgTg', 'https://www.instagram.com/etmangroup.eg/', 'https://www.linkedin.com/company/etman-group/', '201154905424', 'السلاموا عليكم', NULL, NULL, NULL, NULL, NULL, '2023-10-10 06:13:37');

-- --------------------------------------------------------

--
-- Table structure for table `branches`
--

CREATE TABLE `branches` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `phone` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `whatsapp` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lat` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `long` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `direction` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` int(11) NOT NULL DEFAULT 1,
  `postion` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `branches`
--

INSERT INTO `branches` (`id`, `phone`, `whatsapp`, `lat`, `long`, `direction`, `is_active`, `postion`) VALUES
(1, '059-923-0630', NULL, '24.7783135', '46.629138', 'https://www.google.com/maps/dir//%D9%85%D8%B7%D8%B9%D9%85+%D8%B2%D8%A7%D8%AF+%D8%A7%D9%84%D8%B7%D9%8A%D8%A8%D8%A7%D8%AA%E2%80%AD/data=!4m8!4m7!1m0!1m5!1m1!1s0x3e2ee304a73f330d:0x5c64da6668b4ab48!2m2!1d46.6291416!2d24.778314899999998', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `branch_translations`
--

CREATE TABLE `branch_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `branch_id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `work_hours` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `branch_translations`
--

INSERT INTO `branch_translations` (`id`, `branch_id`, `locale`, `title`, `address`, `work_hours`) VALUES
(1, 1, 'ar', 'فرع الرياض', '6945 البحر المتوسط، العقيق، الرياض‎\r\nالرياض 13515‎\r\nالسعودية‎', 'من السبت الى الخميس\r\n10:30 صباحا وحتى 2 صباحا \r\nيوم الجمعة \r\n12:30 مساءا وحتى 2 صباحا');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `parent_id` bigint(20) UNSIGNED DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `postion` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `parent_id`, `photo`, `photo_thum_1`, `icon`, `is_active`, `postion`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, NULL, 'images/category/1/1699180238_KBzB6dEO9xw07YO_.webp', 'images/category/1/1699180238_6cSvnkt436Gz6gg_.webp', NULL, 1, 1, '2023-11-05 09:25:39', '2023-11-05 10:51:30', NULL),
(2, NULL, 'images/category/2/1699180988_t96f3qDKZl9Gepc_.webp', 'images/category/2/1699180988_6e04B5hwZRnxsRp_.webp', NULL, 1, 2, '2023-11-05 09:27:41', '2023-11-05 10:51:30', NULL),
(3, NULL, 'images/category/3/1699180447_Wg75UCNl4DsnYzR_.webp', 'images/category/3/1699180447_PntZKQywOqQNJqt_.webp', NULL, 1, 3, '2023-11-05 09:28:12', '2023-11-05 10:51:30', NULL),
(4, NULL, 'images/category/4/1699180882_AUcDorP5cPzegNB_.webp', 'images/category/4/1699180882_2S6fZx1rc1Fbj9I_.webp', NULL, 1, 4, '2023-11-05 09:28:40', '2023-11-05 10:51:30', NULL),
(5, NULL, 'images/category/5/1699181332_CvltMeLBWQAWTeu_.webp', 'images/category/5/1699181332_hyQuSKUlwV4XMQS_.webp', NULL, 1, 6, '2023-11-05 09:28:50', '2023-11-05 10:51:30', NULL),
(6, NULL, 'images/category/6/1699180727_bIiYvsdnYSsX9YE_.webp', 'images/category/6/1699180727_wDJTLvbakLvQ76K_.webp', NULL, 1, 5, '2023-11-05 09:28:59', '2023-11-05 10:51:30', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `category_product`
--

CREATE TABLE `category_product` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `category_product`
--

INSERT INTO `category_product` (`id`, `category_id`, `product_id`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 1, 3),
(4, 2, 4),
(5, 2, 5),
(6, 2, 6),
(7, 3, 7),
(8, 3, 8),
(9, 3, 9),
(10, 4, 10),
(11, 4, 11),
(12, 4, 12),
(13, 4, 13),
(14, 4, 14),
(15, 4, 15),
(16, 6, 16),
(17, 6, 17),
(18, 6, 18),
(19, 5, 19),
(20, 6, 20),
(21, 6, 21),
(22, 2, 22),
(23, 3, 23),
(24, 1, 24);

-- --------------------------------------------------------

--
-- Table structure for table `category_translations`
--

CREATE TABLE `category_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `des` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_des` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `category_translations`
--

INSERT INTO `category_translations` (`id`, `category_id`, `locale`, `slug`, `name`, `des`, `g_title`, `g_des`) VALUES
(1, 1, 'ar', 'الأطباق-الرئيسية', 'الأطباق الرئيسية', NULL, NULL, NULL),
(2, 2, 'ar', 'الأطباق-الجانبية', 'الأطباق الجانبية', NULL, NULL, NULL),
(3, 3, 'ar', 'أرز', 'أرز', NULL, NULL, NULL),
(4, 4, 'ar', 'المقبلات-والسطلات', 'المقبلات والسطلات', NULL, NULL, NULL),
(5, 5, 'ar', 'الحلى', 'الحلى', NULL, NULL, NULL),
(6, 6, 'ar', 'المشروبات', 'المشروبات', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `config_def_photos`
--

CREATE TABLE `config_def_photos` (
  `id` int(10) UNSIGNED NOT NULL,
  `cat_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postion` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_def_photos`
--

INSERT INTO `config_def_photos` (`id`, `cat_id`, `photo`, `photo_thum_1`, `photo_thum_2`, `postion`, `created_at`, `updated_at`) VALUES
(1, 'light-logo', 'images/def-photo/light-logo-DaZwh2g5b2.webp', NULL, NULL, 2, '2023-09-03 15:03:13', '2023-11-05 11:57:32'),
(2, 'dark-logo', 'images/def-photo/dark-logo-XiwbOBqDPH.webp', NULL, NULL, 1, '2023-09-03 15:04:17', '2023-11-05 11:57:05'),
(5, 'faq-icon', 'images/def-photo/faq-icon-R363TYGGlw.webp', 'images/def-photo/faq-icon-yhrkDB6Lqm.webp', NULL, 0, '2023-09-04 18:17:24', '2023-10-08 12:43:48'),
(6, 'contact-from', 'images/def-photo/contact-from-taOS5rT9SI.webp', NULL, NULL, 0, '2023-09-06 19:37:35', '2023-09-06 19:37:35'),
(8, 'categorie', 'images/def-photo/categorie-FZGQhZRS0I.webp', NULL, NULL, 0, '2023-09-07 16:54:20', '2023-11-05 10:25:12'),
(14, 'form_login', 'images/def-photo/cust-login-5vzy5IZjUZ.webp', NULL, NULL, 0, '2023-09-29 00:45:03', '2023-09-29 03:16:32'),
(15, 'form_sign_up', 'images/def-photo/form-sign-up-AlQFSq2P80.webp', NULL, NULL, 0, '2023-09-29 03:17:07', '2023-09-29 03:33:50');

-- --------------------------------------------------------

--
-- Table structure for table `config_settings`
--

CREATE TABLE `config_settings` (
  `id` int(10) UNSIGNED NOT NULL,
  `web_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `web_status` int(11) NOT NULL DEFAULT 1,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `favicon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_num` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `whatsapp_num` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `whatsapp_text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `facebook` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `youtube` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `instagram` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `linkedin` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `def_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google_api` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `download_app` int(11) NOT NULL DEFAULT 0,
  `top_offer` int(11) NOT NULL DEFAULT 0,
  `apple` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `android` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `windows` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telegram_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telegram_group` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telegram_phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `whatsapp_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `whatsapp_send_to` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_settings`
--

INSERT INTO `config_settings` (`id`, `web_url`, `web_status`, `logo`, `favicon`, `phone_num`, `whatsapp_num`, `phone_text`, `whatsapp_text`, `facebook`, `youtube`, `twitter`, `instagram`, `linkedin`, `def_url`, `google_api`, `download_app`, `top_offer`, `apple`, `android`, `windows`, `telegram_key`, `telegram_group`, `telegram_phone`, `whatsapp_key`, `whatsapp_send_to`, `notes`, `created_at`, `updated_at`) VALUES
(1, '#', 1, '', '', '01006180117', '201006180117', '0100-6180-117', '0100-6180-117', 'https://www.facebook.com/Etman.Group', 'https://www.youtube.com/channel/UC8GkiBf6L9bogsUtx0PEgTg', '#', 'https://www.instagram.com/etmangroup.eg/', 'https://www.linkedin.com/company/etman-group/', 'https://etman-group.com', 'AIzaSyDWuKOMM4hm_uBnQjqQufaLlHSN2QS_4Qo', 1, 1, 'https://www.apple.com/store', 'https://play.google.com/store/apps?hl=en&amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;gl=US', 'https://www.microsoft.com/en-eg/store/', '6313317483:AAEooBTEFel1ej1uaDpXcZzCrbX_ID3aYEw', '-4091280818', '200119925', '8592e88ef28ba32bd5e5b59c11a59f864a898e53b94cbacb04a87dc1f0c377c1887491212d364739', '01555456909', '8592e88ef28ba32bd5e5b59c11a59f864a898e53b94cbacb04a87dc1f0c377c1887491212d364739\r\n01010881921\r\n\r\n6313317483:AAEooBTEFel1ej1uaDpXcZzCrbX_ID3aYEw\r\n-1001989217795\r\n200119925\r\n\r\nsss', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `config_setting_translations`
--

CREATE TABLE `config_setting_translations` (
  `id` int(10) UNSIGNED NOT NULL,
  `setting_id` int(10) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_des` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `closed_mass` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `offer` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_setting_translations`
--

INSERT INTO `config_setting_translations` (`id`, `setting_id`, `locale`, `name`, `g_title`, `g_des`, `closed_mass`, `offer`) VALUES
(1, 1, 'ar', 'عتمان جروب', 'عنوان الصفحة يكتب هنا', 'وصف الصفحة يكتب هنا', 'زوار موقعنا الكرام ... تلبية لرغبتكم الكريمة فى تطوير الموقع \r\nوليرتقى للمستوى العالمى فى تقديم كل ما يهمكم \r\nنحن بصدد تطوير الموقع كليا ليتناسب معكم\r\nادارة الموقع', 'شحن مجانى للطلبات اكثر من 2500 جنية داخل الاسكندرية'),
(2, 1, 'en', 'Etman Group', 'The title of the site is written here', 'The description of the site is written here', 'Dear visitors ... In response to your generous desire to develop the site ... and to rise to the international level in providing everything that interests you ... \r\nWe are in the process of developing the website completely to suit you ..\r\nSite Administration', 'Free Ground Shipping Over  2500 LE');

-- --------------------------------------------------------

--
-- Table structure for table `config_upload_filters`
--

CREATE TABLE `config_upload_filters` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` int(11) NOT NULL DEFAULT 1,
  `convert_state` int(11) NOT NULL DEFAULT 1,
  `quality_val` int(11) NOT NULL DEFAULT 85,
  `new_w` int(11) NOT NULL,
  `new_h` int(11) NOT NULL,
  `canvas_back` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '#ffffff',
  `greyscale` int(11) NOT NULL DEFAULT 0,
  `flip_state` int(11) NOT NULL DEFAULT 0,
  `flip_v` int(11) NOT NULL DEFAULT 0,
  `blur` int(11) NOT NULL DEFAULT 0,
  `blur_size` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `pixelate` int(11) NOT NULL DEFAULT 0,
  `pixelate_size` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '5',
  `text_state` int(11) NOT NULL DEFAULT 0,
  `text_print` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `font_size` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `font_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `font_color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `font_opacity` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `text_position` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `watermark_state` int(11) NOT NULL DEFAULT 0,
  `watermark_img` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `watermark_position` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_upload_filters`
--

INSERT INTO `config_upload_filters` (`id`, `name`, `type`, `convert_state`, `quality_val`, `new_w`, `new_h`, `canvas_back`, `greyscale`, `flip_state`, `flip_v`, `blur`, `blur_size`, `pixelate`, `pixelate_size`, `text_state`, `text_print`, `font_size`, `font_path`, `font_color`, `font_opacity`, `text_position`, `watermark_state`, `watermark_img`, `watermark_position`, `state`, `created_at`, `updated_at`) VALUES
(1, 'NoEdit', 1, 1, 85, 100, 100, '#ffffff', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, '2023-09-06 21:57:01', '2023-09-06 21:57:01'),
(2, 'DefPhoto', 4, 1, 85, 800, 420, '#ffffff', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, '2023-09-06 21:57:01', '2023-09-06 21:57:01'),
(3, 'FavIcon', 4, 1, 85, 40, 40, '#ffffff', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, '2023-09-06 21:57:01', '2023-09-06 21:57:01'),
(4, 'صورة المجموعة', 4, 1, 85, 700, 700, '#FFFFFF', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, '2023-09-06 21:57:01', '2023-09-18 05:33:44'),
(5, 'PhotoGallery', 4, 1, 85, 1024, 768, '#ffffff', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, '2023-09-06 21:57:01', '2023-09-06 21:57:01'),
(6, 'Icon', 4, 1, 85, 300, 300, '#FFFFFF', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, '2023-09-07 11:27:22', '2023-10-08 12:43:19'),
(7, 'بانر', 4, 1, 85, 840, 410, '#FFFFFF', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, '2023-09-11 09:36:55', '2023-09-11 10:03:12'),
(8, 'صورة المنتج', 5, 1, 85, 1000, 1000, '#FFFFFF', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, '2023-09-11 17:01:05', '2023-09-11 17:01:39');

-- --------------------------------------------------------

--
-- Table structure for table `config_upload_filter_sizes`
--

CREATE TABLE `config_upload_filter_sizes` (
  `id` int(10) UNSIGNED NOT NULL,
  `filter_id` int(10) UNSIGNED NOT NULL,
  `type` int(11) NOT NULL DEFAULT 1,
  `new_w` int(11) NOT NULL,
  `new_h` int(11) NOT NULL,
  `canvas_back` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `get_more_option` int(11) NOT NULL DEFAULT 0,
  `get_add_text` int(11) NOT NULL DEFAULT 0,
  `get_watermark` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_upload_filter_sizes`
--

INSERT INTO `config_upload_filter_sizes` (`id`, `filter_id`, `type`, `new_w`, `new_h`, `canvas_back`, `get_more_option`, `get_add_text`, `get_watermark`) VALUES
(1, 2, 4, 500, 335, NULL, 0, 0, 0),
(2, 4, 4, 350, 350, '#FFFFFF', 0, 0, 0),
(3, 5, 4, 800, 600, '#ffffff', 0, 0, 0),
(4, 5, 4, 320, 240, '#ffffff', 0, 0, 0),
(5, 6, 4, 100, 100, '#FFFFFF', 0, 0, 0),
(6, 7, 4, 420, 205, '#FFFFFF', 0, 0, 0),
(7, 8, 5, 350, 350, '#FFFFFF', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `config_web_privacies`
--

CREATE TABLE `config_web_privacies` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `postion` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_web_privacies`
--

INSERT INTO `config_web_privacies` (`id`, `name`, `postion`, `is_active`, `created_at`, `updated_at`) VALUES
(2, 'شروط وسياسة الخصوصية', 2, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(3, 'جمع المعلومات واستخدامها', 3, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(4, 'أنواع البيانات المجمعة', 4, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(5, 'بيانات الاستخدام', 5, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(6, 'تتبع و ملفات تعريف الارتباط', 6, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(7, 'استخدام البيانات', 7, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(8, 'نقل البيانات', 8, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(9, 'الكشف عن البيانات', 9, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(10, 'أمن البيانات', 10, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(11, 'مقدمي الخدمة', 11, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(12, 'تحليلات', 12, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(13, 'روابط لمواقع أخرى', 13, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(14, 'خصوصية الأطفال', 14, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(15, 'تغييرات سياسة الخصوصية', 15, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(16, 'اتصل بنا', 16, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57');

-- --------------------------------------------------------

--
-- Table structure for table `config_web_privacy_translations`
--

CREATE TABLE `config_web_privacy_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `privacy_id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `h1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `h2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `des` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lists` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_web_privacy_translations`
--

INSERT INTO `config_web_privacy_translations` (`id`, `privacy_id`, `locale`, `h1`, `h2`, `des`, `lists`) VALUES
(3, 2, 'ar', 'شروط وسياسة الخصوصية', '', 'تقوم شركة [CompanyName] (\"نحن\" أو \"نحن\" أو \"موقعنا\") بتشغيل [WebSiteName]  (\"الموقع الالكترونى\").\r\nتُعرفك هذه الصفحة بسياساتنا المتعلقة بجمع البيانات الشخصية واستخدامها والكشف عنها عند استخدامك للخدمة والأختيارات المرتبطة بهذه البيانات. \r\nسياسة الخصوصية لشركة [CompanyName]\r\nنستخدم بياناتك لتوفير الخدمة وتحسينها. باستخدام الخدمة، فإنك توافق على جمع واستخدام المعلومات وفقًا لهذه السياسة. ما لم يتم تحديد خلاف ذلك في سياسة الخصوصية، فإن المصطلحات المستخدمة في سياسة الخصوصية لها نفس المعاني كما في الشروط والأحكام الخاصة بنا، والتي يمكن الوصول إليها من [WebSiteName]', ''),
(4, 2, 'en', 'Privacy Policy', '', ' [CompanyName] (\"us\", \"we\", or \"our\") operates the [WebSiteName] website (the \"Service\").\r\nThis page informs you of our policies regarding the collection, use, and disclosure of personal data when you use our Service and the choices you have associated with that data. Our Privacy Policy for [CompanyName]\r\nWe use your data to provide and improve the Service. By using the Service, you agree to the collection and use of information in accordance with this policy. Unless otherwise defined in this Privacy Policy, terms used in this Privacy Policy have the same meanings as in our Terms and Conditions, accessible from  [WebSiteName]', ''),
(5, 3, 'ar', 'جمع المعلومات واستخدامها', '', 'نقوم بتجميع أنواع مختلفة من المعلومات لأغراض متنوعة لتوفير وتحسين خدماتنا لك.', ''),
(6, 3, 'en', 'Information Collection And Use', '', 'We collect several different types of information for various purposes to provide and improve our Service to you.', ''),
(7, 4, 'ar', 'أنواع البيانات المجمعة', 'بيانات شخصية', 'أثناء استخدام خدماتنا ، قد نطلب منك تزويدنا بمعلومات تعريف شخصية معينة يمكن استخدامها للاتصال أو التعرف عليك (&quot;البيانات الشخصية&quot;). قد تتضمن معلومات \r\nالتعريف الشخصية ، على سبيل المثال لا الحصر ، ما يلي:', 'عنوان بريد الكتروني\r\nالاسم الأول واسم العائلة\r\nرقم الهاتف\r\nالعنوان ، الولاية ، المقاطعة ، الرمز البريدي / المدينة ، المدينة\r\nملفات تعريف الارتباط وبيانات الاستخدام'),
(8, 4, 'en', 'Types of Data Collected', 'Personal Data', 'While using our Service, we may ask you to provide us with certain personally identifiable information that can be used to contact or identify you (&quot;Personal Data&quot;). Personally identifiable information may include, but is not limited to :', 'Email address\r\nFirst name and last name\r\nPhone number\r\nAddress, State, Province, ZIP/Postal code, City\r\nCookies and Usage Data'),
(9, 5, 'ar', 'بيانات الاستخدام', '', 'يجوز لنا أيضًا جمع المعلومات حول كيفية الوصول إلى الخدمة واستخدامها (&quot;بيانات الاستخدام&quot;). قد تتضمن بيانات الاستخدام هذه معلومات مثل عنوان بروتوكول الإنترنت الخاص بجهاز الكمبيوتر (مثل عنوان IP) ، ونوع المتصفح، وإصدار المتصفح، وصفحات الخدمة التي تزورها، ووقت وتاريخ زيارتك، والوقت الذي يقضيه في تلك الصفحات، ومعرفات الجهاز وغيرها من البيانات التشخيصية.', ''),
(10, 5, 'en', 'Usage Data', '', 'We may also collect information how the Service is accessed and used (&quot;Usage Data&quot;). This Usage Data may include information such as your computer\'s Internet Protocol address (e.g. IP address), browser type, browser version, the pages of our Service that you visit, the time and date of your visit, the time spent on those pages, unique device identifiers and other diagnostic data.', ''),
(11, 6, 'ar', 'تتبع و ملفات تعريف الارتباط', '', 'نحن نستخدم ملفات تعريف الارتباط وتقنيات التتبع المماثلة لتتبع النشاط على الخدمة لدينا مع الاحتفاظ بمعلومات معينة.\r\nملفات تعريف الارتباط عبارة عن ملفات تحتوي على كمية صغيرة من البيانات التي قد تتضمن معرفًا فريدًا مجهول الهوية. يتم إرسال ملفات تعريف الارتباط إلى متصفحك من موقع الويب وتخزينها على جهازك. تقنيات التتبع المستخدمة هي منارات وعلامات ونصوص لجمع المعلومات وتتبعها ولتحسين خدمتنا وتحليلها.\r\nيمكنك إرشاد المتصفح الخاص بك لرفض جميع ملفات تعريف الارتباط أو للإشارة إلى إرسال ملف تعريف الارتباط. ومع ذلك، إذا كنت لا تقبل ملفات تعريف الارتباط، فقد لا تتمكن من استخدام بعض أجزاء من خدمتنا.\r\n\r\nأمثلة على ملفات تعريف الارتباط التي نستخدمها:', 'نحن نستخدم ملفات تعريف الارتباط الخاصة بالجلسات لتشغيل الخدمة الخاصة بنا.\r\nنحن نستخدم ملفات تعريف الارتباط التفضيلية لتذكر تفضيلاتك والإعدادات المختلفة.\r\nنحن نستخدم ملفات تعريف الارتباط للأمان لأغراض أمنية.'),
(12, 6, 'en', 'Tracking &amp; Cookies Data', '', 'We use cookies and similar tracking technologies to track the activity on our Service and hold certain information.\r\nCookies are files with small amount of data which may include an anonymous unique identifier. Cookies are sent to your browser from a website and stored on your device. Tracking technologies also used are beacons, tags, and scripts to collect and track information and to improve and analyze our Service.\r\nYou can instruct your browser to refuse all cookies or to indicate when a cookie is being sent. However, if you do not accept cookies, you may not be able to use some portions of our Service.\r\n\r\nExamples of Cookies we use:', 'Session Cookies. We use Session Cookies to operate our Service.\r\nPreference Cookies. We use Preference Cookies to remember your preferences and various settings.\r\nSecurity Cookies. We use Security Cookies for security purposes.'),
(13, 7, 'ar', 'استخدام البيانات', '', 'تستخدم [CompanyName] البيانات التي تم جمعها لأغراض مختلفة :', 'لإعلامك عن تغييرات لخدمتنا.\r\nللسماح لك بالمشاركة في الميزات التفاعلية في خدمتنا عندما تختار القيام بذلك.\r\nلتوفير رعاية العملاء والدعم.\r\nلتقديم تحليل أو معلومات قيمة حتى نتمكن من تحسين الخدمة.\r\nلمراقبة استخدام الخدمة.\r\nللكشف عن المشكلات الفنية ومنعها ومعالجتها.'),
(14, 7, 'en', 'Use of Data', '', '[CompanyName] uses the collected data for various purposes:', 'To provide and maintain the Service.\r\nTo notify you about changes to our Service.\r\nTo allow you to participate in interactive features of our Service when you choose to do so.\r\nTo provide customer care and support.\r\nTo provide analysis or valuable information so that we can improve the Service.\r\nTo monitor the usage of the Service.\r\nTo detect, prevent and address technical issues.'),
(15, 8, 'ar', 'نقل البيانات', '', 'قد يتم نقل معلوماتك - بما في ذلك البيانات الشخصية - إلى أجهزة الكمبيوتر الموجودة خارج الولاية أو المقاطعة أو الدولة أو الولاية الحكومية الأخرى التي قد تختلف فيها قوانين حماية البيانات عن تلك الخاصة باختصاصك القضائي.\r\nإذا كنت متواجدًا خارج مصر واخترت تقديم معلومات لنا، يرجى ملاحظة أننا نقوم بنقل البيانات، بما في ذلك البيانات الشخصية، إلى مصر ومعالجتها هناك.\r\nإن موافقتك على سياسة الخصوصية هذه والتي يتبعها تقديمك لهذه المعلومات تمثل موافقتك على هذا النقل \r\nسوف تتخذ [CompanyName] جميع الخطوات الضرورية بشكل معقول لضمان التعامل مع بياناتك بشكل آمن ووفقًا لسياسة الخصوصية هذه ولن يتم نقل بياناتك الشخصية إلى منظمة أو دولة ما لم تكن هناك ضوابط كافية في مكان بما في ذلك أمن البيانات الخاصة بك وغيرها من المعلومات الشخصية.', ''),
(16, 8, 'en', 'Transfer Of Data', '', 'Your information, including Personal Data, may be transferred to — and maintained on — computers located outside of your state, province, country or other governmental jurisdiction where the data protection laws may differ than those from your jurisdiction.\r\nIf you are located outside Egypt and choose to provide information to us, please note that we transfer the data, including Personal Data, to Egypt and process it there.\r\nYour consent to this Privacy Policy followed by your submission of such information represents your agreement to that transfer.\r\n[CompanyName] will take all steps reasonably necessary to ensure that your data is treated securely and in accordance with this Privacy Policy and no transfer of your Personal Data will take place to an organization or a country unless there are adequate controls in place including the security of your data and other personal information.', ''),
(17, 9, 'ar', 'الكشف عن البيانات', 'المتطلبات القانونية', 'يحق لـ [CompanyName] الإفصاح عن بياناتك الشخصية بحسن نية من أن هذا الإجراء ضروري من أجل:', 'للامتثال لالتزام قانوني\r\nلحماية والدفاع عن حقوق أو ملكية [CompanyName]\r\nلمنع أو التحقيق في أي مخالفات محتملة تتعلق بالخدمة.\r\nلحماية السلامة الشخصية لمستخدمي الخدمة أو الجمهور.\r\nللحماية من المسؤولية القانونية.'),
(18, 9, 'en', 'Disclosure Of Data', 'Legal Requirements', '[CompanyName] may disclose your Personal Data in the good faith belief that such action is necessary to:', 'To comply with a legal obligation.\r\nTo protect and defend the rights or property of [CompanyName]\r\nTo prevent or investigate possible wrongdoing in connection with the Service.\r\nTo protect the personal safety of users of the Service or the public.\r\nTo protect against legal liability.'),
(19, 10, 'ar', 'أمن البيانات', '', 'أمان بياناتك مهم بالنسبة لنا، ولكن تذكر أنه لا توجد طريقة للإرسال عبر الإنترنت، أو طريقة التخزين الإلكترونية آمنة ١٠٠٪. بينما نسعى جاهدين لاستخدام وسائل مقبولة تجاريًا لحماية بياناتك الشخصية، لا يمكننا ضمان أمانها المطلق.', ''),
(20, 10, 'en', 'Security Of Data', '', 'The security of your data is important to us, but remember that no method of transmission over the Internet, or method of electronic storage is 100% secure. While we strive to use commercially acceptable means to protect your Personal Data, we cannot guarantee its absolute security.', ''),
(21, 11, 'ar', 'مقدمي الخدمة', '', 'يجوز لنا أن نوظف شركات وأفراد من أطراف ثالثة لتسهيل خدمتنا (&quot;مزودي الخدمة&quot;)، أو تقديم الخدمة نيابة عنا، لأداء الخدمات المتعلقة بالخدمة أو لمساعدتنا في تحليل كيفية استخدام خدمتنا.\r\nهذه الأطراف الثالثة لديها حق الوصول إلى بياناتك الشخصية فقط لأداء هذه المهام نيابة عنا وتكون ملزمة بعدم الكشف عنها أو استخدامها لأي غرض آخر.', ''),
(22, 11, 'en', 'Service Providers', '', 'We may employ third party companies and individuals to facilitate our Service (&quot;Service Providers&quot;), to provide the Service on our behalf, to perform Service-related services or to assist us in analyzing how our Service is used.\r\nThese third parties have access to your Personal Data only to perform these tasks on our behalf and are obligated not to disclose or use it for any other purpose.', ''),
(23, 12, 'ar', 'تحليلات', '', 'قد نستخدم مزودي خدمة من جهات خارجية لمراقبة وتحليل استخدام خدماتنا.', ''),
(24, 12, 'en', 'Analytics', '', 'We may use third-party Service Providers to monitor and analyze the use of our Service.', ''),
(25, 13, 'ar', 'روابط لمواقع أخرى', '', 'قد تحتوي خدمتنا على روابط إلى مواقع أخرى لا يتم تشغيلها من قبلنا. إذا نقرت على رابط جهة خارجية، فسيتم توجيهك إلى موقع الطرف الثالث هذا. ننصحك بشدة بمراجعة سياسة الخصوصية لكل موقع تزوره.\r\n\r\nليس لدينا أي سيطرة ولا نتحمل أي مسؤولية عن المحتوى أو سياسات الخصوصية أو الممارسات الخاصة بأي مواقع أو خدمات خاصة بطرف ثالث.', ''),
(26, 13, 'en', 'Links To Other Sites', '', 'Our Service may contain links to other sites that are not operated by us. If you click on a third party link, you will be directed to that third party\'s site. We strongly advise you to review the Privacy Policy of every site you visit.\r\n\r\nWe have no control over and assume no responsibility for the content, privacy policies or practices of any third party sites or services.', ''),
(27, 14, 'ar', 'خصوصية الأطفال', '', 'لا تتناول خدمتنا أي شخص دون سن ١٨ عامًا (&quot;الأطفال&quot;).\r\nنحن لا نجمع معلومات التعريف الشخصية من أي شخص دون سن ١٨ عامًا. إذا كنت أحد الوالدين أو الوصي وكنت على علم بأن أطفالك قد زودونا ببيانات شخصية، يرجى الاتصال بنا. إذا علمنا أننا جمعنا بيانات شخصية من الأطفال دون التحقق من موافقة الوالدين، فإننا نتخذ خطوات لإزالة تلك المعلومات من خوادمنا.', ''),
(28, 14, 'en', 'Children\'s Privacy', '', 'Our Service does not address anyone under the age of 18 (&quot;Children&quot;).\r\nWe do not knowingly collect personally identifiable information from anyone under the age of 18. If you are a parent or guardian and you are aware that your Children has provided us with Personal Data, please contact us. If we become aware that we have collected Personal Data from children without verification of parental consent, we take steps to remove that information from our servers.', ''),
(29, 15, 'ar', 'تغييرات سياسة الخصوصية', '', 'يجوز لنا تحديث سياسة الخصوصية الخاصة بنا من وقت لآخر. سنعلمك بأي تغييرات عن طريق نشر سياسة الخصوصية الجديدة على هذه الصفحة.\r\nسنخبرك عبر البريد الإلكتروني و/ أو بإشعار بارز في خدمتنا، قبل أن يصبح التغيير ساريًا وتحديث &quot;تاريخ الفعالية&quot; في أعلى سياسة الخصوصية هذه.\r\nننصحك بمراجعة سياسة الخصوصية هذه بشكل دوري لأية تغييرات. تسري التغييرات التي تطرأ على سياسة الخصوصية هذه عند نشرها على هذه الصفحة.', ''),
(30, 15, 'en', 'Changes To This Privacy Policy', '', 'We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page.\r\n\r\nWe will let you know via email and/or a prominent notice on our Service, prior to the change becoming effective and update the &quot;effective date&quot; at the top of this Privacy Policy.\r\n\r\nYou are advised to review this Privacy Policy periodically for any changes. Changes to this Privacy Policy are effective when they are posted on this page.', ''),
(31, 16, 'ar', 'اتصل بنا', '', 'إذا كان لديك أي أسئلة حول سياسة الخصوصية هذه، يرجى الاتصال بنا:', 'البريد الإلكتروني : info@etman-group.com'),
(32, 16, 'en', 'Contact Us', '', 'If you have any questions about this Privacy Policy, please contact us:', 'Email:info@etman-group.com');

-- --------------------------------------------------------

--
-- Table structure for table `contact_us_forms`
--

CREATE TABLE `contact_us_forms` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `data_cities`
--

CREATE TABLE `data_cities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `data_cities`
--

INSERT INTO `data_cities` (`id`, `name`, `name_en`, `is_active`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'القاهرة', 'Cairo', 1, NULL, NULL, NULL),
(2, 'القاهرة الجديدة', 'New Cairo', 1, NULL, NULL, NULL),
(3, 'الاسكندرية', 'Alexandria', 1, NULL, NULL, NULL),
(4, 'الاسماعيلية', 'Ismailia', 1, NULL, NULL, NULL),
(5, 'اسوان', 'Aswan', 1, NULL, NULL, NULL),
(6, 'اسيوط', 'Asyut', 1, NULL, NULL, NULL),
(7, 'الاقصر', 'Luxor', 1, NULL, NULL, NULL),
(8, 'البحر الاحمر', 'Red Sea', 1, NULL, NULL, NULL),
(9, 'البحيرة', 'Beheira ', 1, NULL, NULL, NULL),
(10, 'بني سويف', 'Beni Suef', 1, NULL, NULL, NULL),
(11, 'بورسعيد', 'Port Said', 1, NULL, NULL, NULL),
(12, 'جنوب سيناء', 'South Sinai', 1, NULL, NULL, NULL),
(13, 'الجيزة', 'Giza', 1, NULL, NULL, NULL),
(14, 'الدقهلية', 'Dakahlia', 1, NULL, NULL, NULL),
(15, 'دمياط', 'Damietta', 1, NULL, NULL, NULL),
(16, 'سوهاج', 'Sohag', 1, NULL, NULL, NULL),
(17, 'السويس', 'Suez', 1, NULL, NULL, NULL),
(18, 'الشرقية', 'Sharqia', 1, NULL, NULL, NULL),
(19, 'شمال سيناء', 'North Sinai', 1, NULL, NULL, NULL),
(20, 'الغربية', 'Gharbia', 1, NULL, NULL, NULL),
(21, 'الفيوم', 'Faiyum', 1, NULL, NULL, NULL),
(22, 'القليوبية', 'Qalyubia', 1, NULL, NULL, NULL),
(23, 'قنا', 'Qena', 1, NULL, NULL, NULL),
(24, 'كفر الشيخ', 'Kafr El Sheikh', 1, NULL, NULL, NULL),
(25, 'مطروح', 'Matruh', 1, NULL, NULL, NULL),
(26, 'المنوفية', 'Monufia', 1, NULL, NULL, NULL),
(27, 'المنيا', 'Minya', 1, NULL, NULL, NULL),
(28, 'الوادى الجديد', 'New Valley', 1, NULL, NULL, NULL),
(29, 'غير محدد', 'undefined', 1, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(586, '2014_10_12_000000_create_users_table', 1),
(587, '2014_10_12_100000_create_password_reset_tokens_table', 1),
(588, '2014_10_12_100000_create_password_resets_table', 1),
(589, '2019_08_19_000000_create_failed_jobs_table', 1),
(590, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(591, '2023_06_24_105531_create_settings_table', 1),
(592, '2023_06_24_144232_create_setting_translations_table', 1),
(593, '2023_06_29_193744_create_def_photos_table', 1),
(594, '2023_06_29_235416_create_upload_filters_table', 1),
(595, '2023_07_03_115945_create_upload_filter_sizes_table', 1),
(596, '2023_07_12_171931_create_permission_tables', 1),
(597, '2023_07_14_112208_add_names_roles_table', 1),
(598, '2023_07_14_115125_add_names_permissions_table', 1),
(599, '2023_07_16_155230_create_categories_table', 1),
(600, '2023_07_16_155651_create_category_translations_table', 1),
(601, '2023_08_23_130011_create_products_table', 1),
(602, '2023_08_23_130057_create_product_translations_table', 1),
(603, '2023_08_23_172346_create_product_photos_table', 1),
(604, '2023_08_24_145512_create_web_privacies_table', 1),
(605, '2023_08_24_145811_create_web_privacy_translations_table', 1),
(606, '2023_08_29_091745_create_pages_table', 1),
(607, '2023_08_29_091812_create_page_translations_table', 1),
(608, '2023_09_17_172739_create_product_category_table', 1),
(609, '2023_09_23_143553_create_shoppingcart_table', 1),
(610, '2023_09_28_141144_create_users_customers_table', 1),
(611, '2023_09_29_143600_create_data_cities_table', 1),
(612, '2023_09_29_173742_create_users_customers_addresses_table', 1),
(613, '2023_09_30_131508_create_shopping_order_addresses_table', 1),
(614, '2023_09_30_131534_create_shopping_orders_table', 1),
(615, '2023_09_30_131551_create_shopping_order_products_table', 1),
(616, '2023_10_04_055847_create_news_letters_table', 1),
(617, '2023_10_05_123803_create_shopping_order_logs_table', 1),
(618, '2023_10_07_163342_create_contact_us_forms_table', 1),
(619, '2023_10_09_161835_create_app_settings_table', 1),
(620, '2023_10_10_101008_create_app_menus_table', 1),
(621, '2023_10_10_101035_create_app_menu_translations_table', 1),
(622, '2023_10_10_171316_create_opening_hours_table', 1),
(623, '2023_10_10_223620_create_branches_table', 1),
(624, '2023_10_10_223647_create_branch_translations_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `model_has_permissions`
--

CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `model_has_roles`
--

CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `model_has_roles`
--

INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
(1, 'App\\Models\\User', 1),
(2, 'App\\Models\\User', 2),
(3, 'App\\Models\\User', 3),
(4, 'App\\Models\\User', 3),
(4, 'App\\Models\\User', 4),
(7, 'App\\Models\\User', 3),
(7, 'App\\Models\\User', 4);

-- --------------------------------------------------------

--
-- Table structure for table `news_letters`
--

CREATE TABLE `news_letters` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `opening_hours`
--

CREATE TABLE `opening_hours` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `day` int(11) NOT NULL,
  `postion` int(11) NOT NULL DEFAULT 0,
  `name_ar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `open_from` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `open_to` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `delivery_from` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `delivery_to` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `opening_hours`
--

INSERT INTO `opening_hours` (`id`, `day`, `postion`, `name_ar`, `name_en`, `open_from`, `open_to`, `delivery_from`, `delivery_to`) VALUES
(1, 0, 2, 'الاحد', 'Sunday', '10:30', '02:00', '10:30', '02:00'),
(2, 1, 3, 'الاثنين', 'Monday', '10:30', '02:00', '10:30', '02:00'),
(3, 2, 4, 'الثلاثاء', 'Tuesday', '10:30', '02:00', '10:30', '02:00'),
(4, 3, 5, 'الاربعاء', 'Wednesday', '10:30', '02:00', '10:30', '02:00'),
(5, 4, 6, 'الخميس', 'Thursday', '10:30', '02:00', '10:30', '02:00'),
(6, 5, 7, 'الجمعه', 'Friday', '12:30', '02:00', '00:30', '02:00'),
(7, 6, 1, 'السبت', 'Saturday', '10:30', '02:00', '10:30', '02:00');

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` int(10) UNSIGNED NOT NULL,
  `cat_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `view_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `banner_id` int(11) DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `menu_main` tinyint(1) NOT NULL DEFAULT 0,
  `menu_footer` tinyint(1) NOT NULL DEFAULT 0,
  `postion` int(11) NOT NULL DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `cat_id`, `view_name`, `banner_id`, `photo`, `photo_thum_1`, `is_active`, `menu_main`, `menu_footer`, `postion`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'HomePage', NULL, 4, NULL, NULL, 1, 1, 1, 1, NULL, '2023-08-29 06:41:34', '2023-09-11 09:39:37'),
(2, 'OurClient', NULL, NULL, NULL, NULL, 1, 1, 1, 3, NULL, '2023-08-29 06:41:34', '2023-09-08 12:56:32'),
(3, 'LatestNews', NULL, NULL, NULL, NULL, 1, 1, 1, 4, NULL, '2023-08-29 06:41:34', '2023-09-03 09:21:59'),
(4, 'ErrorPage', NULL, NULL, NULL, NULL, 1, 0, 0, 8, NULL, '2023-08-29 06:41:34', '2023-09-03 07:25:20'),
(5, 'FaqList', NULL, NULL, NULL, NULL, 1, 1, 1, 5, NULL, '2023-08-29 06:41:34', '2023-09-03 07:44:55'),
(6, 'TermsConditions', NULL, NULL, NULL, NULL, 1, 0, 1, 6, NULL, '2023-08-29 06:41:34', '2023-09-03 07:45:03'),
(7, 'ContactUs', NULL, NULL, NULL, NULL, 1, 1, 1, 7, NULL, '2023-08-29 06:41:34', '2023-09-03 07:45:14'),
(8, 'AboutUs', NULL, NULL, NULL, NULL, 1, 1, 1, 2, NULL, '2023-08-29 06:41:34', '2023-09-03 07:44:30'),
(9, 'MainCategory', NULL, NULL, NULL, NULL, 1, 1, 1, 0, NULL, '2023-09-08 13:19:30', '2023-09-08 13:19:51'),
(10, 'Shop_HomePage', NULL, 1, NULL, NULL, 1, 1, 1, 0, NULL, '2023-09-11 12:37:49', '2023-09-11 12:37:49'),
(11, 'Shop_BestDeals', NULL, NULL, NULL, NULL, 1, 1, 1, 0, NULL, '2023-09-11 21:09:15', '2023-09-11 21:09:15'),
(12, 'Shop_WeekOffers', NULL, NULL, NULL, NULL, 1, 1, 1, 0, NULL, '2023-09-22 10:26:01', '2023-09-22 10:26:01'),
(13, 'Shop_Recently', NULL, NULL, NULL, NULL, 1, 1, 1, 0, NULL, '2023-09-22 10:26:55', '2023-09-22 10:26:55');

-- --------------------------------------------------------

--
-- Table structure for table `page_translations`
--

CREATE TABLE `page_translations` (
  `id` int(10) UNSIGNED NOT NULL,
  `page_id` int(10) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_des` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body_h1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `breadcrumb` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `page_translations`
--

INSERT INTO `page_translations` (`id`, `page_id`, `locale`, `slug`, `name`, `g_title`, `g_des`, `body_h1`, `breadcrumb`) VALUES
(1, 1, 'ar', 'home', 'الصفحة الرئيسية', 'عتمان جروب فخر الصناعة المصرية | خدمة العملاء 01006180117', 'عتمان جروب فخر الصناعة المصرية متخصصون فى تصنيع الاشرطة ذاتية اللصق وشرائط الزينة و جميع مستلزمات التعبئة والتغليف بمصر الاسكندرية خدمة العملاء 01006180117', 'عتمان جروب', 'عتمان جروب'),
(2, 1, 'en', 'home', 'Home Page', 'Etman Group is the pride of the Egyptian industry Hotline 01006180117', 'Etman Group,the pride of the Egyptian industry, specialized in the manufacture of self-adhesive tapes, PP Ribbon and all packaging Products Hotline 01006180117', 'Etman Group', 'Etman Group'),
(3, 2, 'ar', 'عملائنا', 'عملائنا', 'عتمان جروب | قائمة بعملائنا', 'بعد اكثر من 40 عام من العمل فى السوق المصرى نتشرف بخدمة عملائنا التى تشرفنا بخدمتهم على مدار السنوات السابقة', 'عملائنا', 'عملائنا'),
(4, 2, 'en', 'our-client', 'Our Client', 'Etman Group | Our Client', 'After more than 40 years of working in the Egyptian market, we are honored to serve our customers, which we were honored to serve over the past years', 'Our Client', 'Our Client'),
(5, 3, 'ar', 'أخر-الأخبار', 'أخر الأخبار', 'عتمان جروب | أخر الاخبار | احدث العروض | الوظائف المتاحة', 'تابع اخر اخبار شركة عتمان جروب وكن دائما على علم باحداث العروض والخصومات التى نقدمه دائما والوظائف المتوفرة حاليا', 'أخر الأخبار', 'أخر الأخبار'),
(6, 3, 'en', 'latest-news', 'Latest news', 'Etman Group | Latest news | Latest Offers | Available jobs', 'Follow latest news of the Etman Group and always be aware of the latest offers and discounts that we always offer and the jobs that are currently available', 'Latest news', 'Latest news'),
(7, 4, 'ar', 'page-not-found', '404', 'عذرا !! الصفحة غير موجودة', 'عذرا !! الصفحة غير موجودة', NULL, NULL),
(8, 4, 'en', 'page-not-found', '404', 'Sorry !! Page not found', 'Sorry !! Page not found', NULL, NULL),
(9, 5, 'ar', 'الأسئلة-المتكررة', 'الأسئلة المتكررة', 'الأسئلة المتكررة | عتمان جروب | الاسكندرية 01006180117', 'تساعدك الأسئلة المتكررة على الرد لجميع الاستفسارت الخاصة بالمنتجات والعروض وطرق الشحن وطرق الدفع المتاحة لدى عتمان جروب', 'الأسئلة المتكررة', 'الأسئلة المتكررة'),
(10, 5, 'en', 'frequently-asked-questions', 'FAQ', 'Frequently Asked Questions | Etman Group | 01006180117', 'Frequently asked questions help you answer all inquiries about products, offers, shipping methods and payment methods available at Etman Group', 'Frequently Asked Questions', 'Frequently Asked Questions'),
(11, 6, 'ar', 'سياسية-الاستخدام', 'سياسية الاستخدم', 'عتمان جروب | شروط وسياسة الخصوصية', 'شروط وسياسة الخصوصية تعرفك هذه الصفحة بسياساتنا المتعلقة بجمع البيانات الشخصية واستخدامها والكشف عنها عند استخدامك للخدمة والأختيارات المرتبطة بهذه البيانات.', 'سياسية الاستخدم', NULL),
(12, 6, 'en', 'terms-conditions', 'Privacy Policy', 'Etman Group | Our Privacy Policy', 'Terms and Privacy Policy This page informs you of our policies regarding the collection, use and disclosure of personal data when you use the Service', 'Terms & Conditions', NULL),
(13, 7, 'ar', 'اتصل-بنا', 'اتصل بنا', 'عتمان جروب | اتصل بنا | الاسكندرية 01006180117', 'عتمان جروب المقر الرئيسي 14 ش خليل بك متفرع من اسماعيل صبري - أمام بنك مصر - الجمرك الاسكندرية - مصر / هاتف 01006180117', 'اتصل بنا', NULL),
(14, 7, 'en', 'contact-us', 'Contact Us', 'Etman Group | Contact Us | Alexandria 0100-6180-117', 'Etman Group Headquarters 14 Khalil Bey St., off Ismail Sabry - in front of Banque Misr - Customs, Alexandria - Egypt  Phone : 01006180117', 'Contact Us', NULL),
(15, 8, 'ar', 'من-نحن', 'من نحن', 'عتمان جروب هي شركة محلية منذ عام 1967 | الاسكندرية 01006180117', 'عتمان جروب هي شركة محلية أسسها السيد حسن عتمان منذ عام 1967. بدأت رحلة السيد عتمان نحو النجاح بفضل تطور شركته من خلال إنتاج شرائط البولي بروبلين وشرائط الزينة', 'من نحن', 'من نحن'),
(16, 8, 'en', 'about-us', 'About Us', 'Etman Group is a local company since 1967 | Alexandria 01006180117', 'Etman Group is a local company founded and operated by Mr Hassan Etman in 1967. Mr Etman’s journey to success started due to the development of his company by', 'About Us', 'About Us'),
(17, 9, 'ar', 'قائمة-المنتجات', 'قائمة المنتجات', 'قائمة المنتجات', 'قائمة المنتجات', 'قائمة المنتجات', 'قائمة المنتجات'),
(18, 9, 'en', 'category-list', 'Category List', 'Category List', 'Category List', 'Category List', 'Category List'),
(19, 10, 'ar', 'تسوق-الان-مع-عتمان', 'تسوق الان مع عتمان', 'تسوق الان مع عتمان', 'تسوق الان مع عتمان', 'تسوق الان مع عتمان', 'تسوق الان مع عتمان'),
(20, 10, 'en', 'shop-now', 'Shop Now', 'Shop Now', 'Shop Now', 'Shop Now', 'Shop Now'),
(21, 11, 'ar', 'عروض-تجار-الجملة', 'عروض تجار الجملة', 'عروض تجار الجملة', 'عروض تجار الجملة', 'عروض تجار الجملة', 'عروض تجار الجملة'),
(22, 11, 'en', 'عروض-تجار-الجملة', 'عروض تجار الجملة', 'عروض تجار الجملة', 'عروض تجار الجملة', 'عروض تجار الجملة', 'عروض تجار الجملة'),
(23, 12, 'ar', 'العروض-الاسبوعية', 'العروض الاسبوعية', 'العروض الاسبوعية', 'العروض الاسبوعية', 'العروض الاسبوعية', 'العروض الاسبوعية'),
(24, 12, 'en', 'العروض-الاسبوعية', 'العروض الاسبوعية', 'العروض الاسبوعية', 'العروض الاسبوعية', 'العروض الاسبوعية', 'العروض الاسبوعية'),
(25, 13, 'ar', 'وصل-حديثا', 'وصل حديثا', 'وصل حديثا', 'وصل حديثا', 'وصل حديثا', 'وصل حديثا'),
(26, 13, 'en', 'وصل-حديثا', 'وصل حديثا', 'وصل حديثا', 'وصل حديثا', 'وصل حديثا', 'وصل حديثا');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `cat_id` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_ar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `cat_id`, `name`, `name_ar`, `name_en`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 1, 'users_view', 'عرض', 'View', 'web', '2023-11-05 14:43:13', '2023-11-05 14:43:13'),
(2, 1, 'users_add', 'اضافة', 'Add', 'web', '2023-11-05 14:43:13', '2023-11-05 14:43:13'),
(3, 1, 'users_edit', 'تعديل', 'Edit', 'web', '2023-11-05 14:43:13', '2023-11-05 14:43:13'),
(4, 1, 'users_delete', 'حذف', 'Delete', 'web', '2023-11-05 14:43:13', '2023-11-05 14:43:13'),
(5, 2, 'roles_view', 'عرض', 'View', 'web', '2023-11-05 14:43:13', '2023-11-05 14:43:13'),
(6, 2, 'roles_add', 'اضافة', 'Add', 'web', '2023-11-05 14:43:13', '2023-11-05 14:43:13'),
(7, 2, 'roles_edit', 'تعديل', 'Edit', 'web', '2023-11-05 14:43:13', '2023-11-05 14:43:13'),
(8, 2, 'roles_delete', 'حذف', 'Delete', 'web', '2023-11-05 14:43:13', '2023-11-05 14:43:13'),
(9, 2, 'roles_update_permissions', 'تعديل صلاحيات المجموعة', 'Roles Update Permissions', 'web', '2023-11-05 14:43:13', '2023-11-05 14:43:13'),
(10, 3, 'permissions_view', 'عرض', 'View', 'web', '2023-11-05 14:43:13', '2023-11-05 14:43:13'),
(11, 3, 'permissions_add', 'اضافة', 'Add', 'web', '2023-11-05 14:43:13', '2023-11-05 14:43:13'),
(12, 3, 'permissions_edit', 'تعديل', 'Edit', 'web', '2023-11-05 14:43:13', '2023-11-05 14:43:13'),
(13, 3, 'permissions_delete', 'حذف', 'Delete', 'web', '2023-11-05 14:43:13', '2023-11-05 14:43:13'),
(14, 4, 'webPrivacy_view', 'عرض', 'View', 'web', '2023-11-05 14:43:13', '2023-11-05 14:43:13'),
(15, 4, 'webPrivacy_add', 'اضافة', 'Add', 'web', '2023-11-05 14:43:13', '2023-11-05 14:43:13'),
(16, 4, 'webPrivacy_edit', 'تعديل', 'Edit', 'web', '2023-11-05 14:43:13', '2023-11-05 14:43:13'),
(17, 4, 'webPrivacy_delete', 'حذف', 'Delete', 'web', '2023-11-05 14:43:13', '2023-11-05 14:43:13'),
(18, 5, 'adminlang_view', 'عرض ملفات لغة التحكم', 'View Admin Lang', 'web', '2023-11-05 14:43:13', '2023-11-05 14:43:13'),
(19, 5, 'adminlang_edit', 'تعديل ملفات لغة التحكم', 'Edit Admin Lang', 'web', '2023-11-05 14:43:13', '2023-11-05 14:43:13'),
(20, 5, 'weblang_view', 'عرض ملفات لغة الموقع', 'View', 'web', '2023-11-05 14:43:13', '2023-11-05 14:43:13'),
(21, 5, 'weblang_edit', 'تعديل ملفات لغة الموقع', 'Edit', 'web', '2023-11-05 14:43:13', '2023-11-05 14:43:13'),
(22, 6, 'config_section', 'عرض الاعدادات', 'Setting View', 'web', '2023-11-05 14:43:13', '2023-11-05 14:43:13'),
(23, 6, 'website_config', 'اعدادات الموقع', 'Web Site Setting', 'web', '2023-11-05 14:43:13', '2023-11-05 14:43:13'),
(24, 7, 'defPhoto_view', 'عرض', 'View', 'web', '2023-11-05 14:43:13', '2023-11-05 14:43:13'),
(25, 7, 'defPhoto_add', 'اضافة', 'Add', 'web', '2023-11-05 14:43:13', '2023-11-05 14:43:13'),
(26, 7, 'defPhoto_edit', 'تعديل', 'Edit', 'web', '2023-11-05 14:43:13', '2023-11-05 14:43:13'),
(27, 7, 'defPhoto_delete', 'حذف', 'Delete', 'web', '2023-11-05 14:43:13', '2023-11-05 14:43:13'),
(28, 8, 'upFilter_view', 'عرض', 'View', 'web', '2023-11-05 14:43:13', '2023-11-05 14:43:13'),
(29, 8, 'upFilter_add', 'اضافة', 'Add', 'web', '2023-11-05 14:43:13', '2023-11-05 14:43:13'),
(30, 8, 'upFilter_edit', 'تعديل', 'Edit', 'web', '2023-11-05 14:43:13', '2023-11-05 14:43:13'),
(31, 8, 'upFilter_delete', 'حذف', 'Delete', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(32, 9, 'Pages_view', 'عرض', 'View', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(33, 9, 'Pages_add', 'اضافة', 'Add', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(34, 9, 'Pages_edit', 'تعديل', 'Edit', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(35, 9, 'Pages_delete', 'حذف', 'Delete', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(36, 9, 'Pages_restore', 'استعادة المحذوف', 'Restore', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(37, 9, 'Pages_edit_slug', 'Edit Slug', 'Edit Slug', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(38, 10, 'category_view', 'عرض', 'View', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(39, 10, 'category_add', 'اضافة', 'Add', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(40, 10, 'category_edit', 'تعديل', 'Edit', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(41, 10, 'category_delete', 'حذف', 'Delete', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(42, 10, 'category_restore', 'استعادة المحذوف', 'Restore', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(43, 10, 'category_edit_slug', 'Edit Slug', 'Edit Slug', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(44, 11, 'product_view', 'عرض', 'View', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(45, 11, 'product_add', 'اضافة', 'Add', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(46, 11, 'product_edit', 'تعديل', 'Edit', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(47, 11, 'product_delete', 'حذف', 'Delete', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(48, 11, 'product_edit_slug', 'Edit Slug', 'Edit Slug', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(49, 12, 'AppSetting_view', 'AppSetting_view', 'View', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(50, 12, 'AppSetting_menu', 'AppSetting_menu', 'Add', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(51, 12, 'AppSetting_config', 'AppSetting_config', 'Edit', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(52, 12, 'AppSetting_photo', 'AppSetting_photo', 'Delete', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(53, 13, 'BlogPost_view', 'عرض', 'View', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(54, 13, 'BlogPost_add', 'اضافة', 'Add', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(55, 13, 'BlogPost_edit', 'تعديل', 'Edit', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(56, 13, 'BlogPost_delete', 'حذف', 'Delete', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(57, 13, 'BlogPost_restore', 'استعادة المحذوف', 'Restore', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(58, 13, 'BlogPost_edit_slug', 'Edit Slug', 'Edit Slug', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(59, 14, 'Banner_view', 'عرض', 'View', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(60, 14, 'Banner_add', 'اضافة', 'Add', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(61, 14, 'Banner_edit', 'تعديل', 'Edit', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(62, 14, 'Banner_delete', 'حذف', 'Delete', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(63, 14, 'Banner_restore', 'استعادة المحذوف', 'Restore', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(64, 15, 'Faq_view', 'عرض', 'View', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(65, 15, 'Faq_add', 'اضافة', 'Add', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(66, 15, 'Faq_edit', 'تعديل', 'Edit', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(67, 15, 'Faq_delete', 'حذف', 'Delete', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(68, 15, 'Faq_restore', 'استعادة المحذوف', 'Restore', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(69, 15, 'Faq_edit_slug', 'Edit Slug', 'Edit Slug', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(70, 16, 'shopProduct_view', 'عرض', 'View', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(71, 16, 'shopProduct_add', 'اضافة', 'Add', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(72, 16, 'shopProduct_edit', 'تعديل', 'Edit', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(73, 16, 'shopProduct_delete', 'حذف', 'Delete', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(74, 16, 'shopProduct_restore', 'استعادة المحذوف', 'Restore', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(75, 16, 'shopProduct_edit_slug', 'Edit Slug', 'Edit Slug', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(76, 17, 'shopCategory_view', 'عرض', 'View', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(77, 17, 'shopCategory_add', 'اضافة', 'Add', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(78, 17, 'shopCategory_edit', 'تعديل', 'Edit', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(79, 17, 'shopCategory_delete', 'حذف', 'Delete', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(80, 17, 'shopCategory_restore', 'استعادة المحذوف', 'Restore', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(81, 17, 'shopCategory_edit_slug', 'Edit Slug', 'Edit Slug', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(82, 18, 'ShopCustomer_view', 'عرض', 'View', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(83, 18, 'ShopCustomer_add', 'اضافة', 'Add', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(84, 18, 'ShopCustomer_edit', 'تعديل', 'Edit', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(85, 18, 'ShopCustomer_delete', 'حذف', 'Delete', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(86, 18, 'ShopCustomer_restore', 'استعادة المحذوف', 'Restore', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(87, 19, 'ShopOrders_view', 'عرض', 'View', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(88, 19, 'ShopOrders_add', 'اضافة', 'Add', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(89, 19, 'ShopOrders_edit', 'تعديل', 'Edit', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(90, 19, 'ShopOrders_delete', 'حذف', 'Delete', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14'),
(91, 19, 'ShopOrders_restore', 'استعادة المحذوف', 'Restore', 'web', '2023-11-05 14:43:14', '2023-11-05 14:43:14');

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `sku` int(11) DEFAULT NULL,
  `price` double(8,2) DEFAULT NULL,
  `sale_price` double(8,2) DEFAULT NULL,
  `qty_left` int(11) DEFAULT NULL,
  `qty_max` int(11) DEFAULT NULL,
  `unit` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_archived` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `sku`, `price`, `sale_price`, `qty_left`, `qty_max`, `unit`, `photo`, `photo_thum_1`, `is_active`, `is_archived`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, NULL, 21.00, NULL, 1000, 100, NULL, 'images/product/1/1699184663_exdRuiSTd7oEuTF_.webp', 'images/product/1/1699184663_jEGHCGTurMNhfZt_.webp', 1, 0, '2023-11-05 09:31:15', '2023-11-05 11:44:23', NULL),
(2, NULL, 21.00, NULL, 1000, 100, NULL, 'images/product/2/1699184794_Sy9YR3W3VcF32Q2_.webp', 'images/product/2/1699184794_FdlzBWsuDoBuM53_.webp', 1, 0, '2023-11-05 09:31:37', '2023-11-05 11:46:34', NULL),
(3, NULL, 40.00, NULL, 1000, 100, NULL, 'images/product/3/1699184883_3ZUEHlcG0rtydjQ_.webp', 'images/product/3/1699184884_ySqybM8a6GGUACo_.webp', 1, 0, '2023-11-05 09:32:24', '2023-11-05 11:49:45', NULL),
(4, NULL, 10.00, NULL, 1000, 100, NULL, 'images/product/4/1699183903_xcyUISFsYvK7K81_.webp', 'images/product/4/1699183903_2WKhVJ2Hz7v6unt_.webp', 1, 0, '2023-11-05 09:33:17', '2023-11-05 11:31:43', NULL),
(5, NULL, 10.00, NULL, 1000, 100, NULL, 'images/product/5/1699183212_a4NKwC7F925gAFk_.webp', 'images/product/5/1699183213_FqOikALhpwv9N6u_.webp', 1, 0, '2023-11-05 09:33:41', '2023-11-05 11:20:13', NULL),
(6, NULL, 10.00, NULL, 1000, 100, NULL, 'images/product/6/1699183247_Apb0t5ICBh2mV8G_.webp', 'images/product/6/1699183247_r6jG7C57EXTXJR3_.webp', 1, 0, '2023-11-05 09:33:59', '2023-11-05 11:20:47', NULL),
(7, NULL, 7.00, NULL, 1000, 100, NULL, 'images/product/7/1699184191_N5T1OQIY3mpT9SD_.webp', 'images/product/7/1699184191_36l0EQjdtPFLxGe_.webp', 1, 0, '2023-11-05 09:34:22', '2023-11-05 11:36:31', NULL),
(8, NULL, 7.00, NULL, 1000, 100, NULL, 'images/product/8/1699184402_kCuFUaj2b6CT2pI_.webp', 'images/product/8/1699184402_8QWyNy7iZTtaZe8_.webp', 1, 0, '2023-11-05 09:34:41', '2023-11-05 11:40:02', NULL),
(9, NULL, 7.00, NULL, 1000, 100, NULL, 'images/product/9/1699184598_YM8cnBHYbVVI3qz_.webp', 'images/product/9/1699184599_lpb6asV4glKX5Vo_.webp', 1, 0, '2023-11-05 09:34:56', '2023-11-05 11:43:19', NULL),
(10, NULL, 7.00, NULL, 1000, 100, NULL, 'images/product/10/1699182733_XmnCaXwRs6qMECy_.webp', 'images/product/10/1699182733_c8eooheaPM3BNW9_.webp', 1, 0, '2023-11-05 09:35:34', '2023-11-05 11:12:13', NULL),
(11, NULL, 7.00, NULL, 1000, 100, NULL, 'images/product/11/1699182874_E7z1yr0rzlmvmLP_.webp', 'images/product/11/1699182874_T4je9kfxwjrMXK9_.webp', 1, 0, '2023-11-05 09:35:55', '2023-11-05 11:14:34', NULL),
(12, NULL, 5.00, NULL, 1000, 100, NULL, 'images/product/12/1699183039_hRKirPA4wZbCmWF_.webp', 'images/product/12/1699183039_4PzmpwgX47qKAa7_.webp', 1, 0, '2023-11-05 09:36:17', '2023-11-05 11:17:19', NULL),
(13, NULL, 2.00, NULL, 1000, 100, NULL, 'images/product/13/1699185231_h7npIAe3J90ixVx_.webp', 'images/product/13/1699185232_inLncQDMGl6acXY_.webp', 1, 0, '2023-11-05 09:36:41', '2023-11-05 11:53:52', NULL),
(14, NULL, 3.00, NULL, 1000, 100, NULL, 'images/product/14/1699182664_ydCsR8QFLl4w8Bt_.webp', 'images/product/14/1699182664_wIOLNUFhA0BpedQ_.webp', 1, 0, '2023-11-05 09:37:06', '2023-11-05 11:11:04', NULL),
(15, NULL, 2.00, NULL, 1000, 100, NULL, 'images/product/15/1699182646_7c5oC9MTJeVXZVJ_.webp', 'images/product/15/1699182646_F0rjejTMqlM8fjq_.webp', 1, 0, '2023-11-05 09:37:39', '2023-11-05 11:10:46', NULL),
(16, NULL, 2.00, NULL, 1000, 100, NULL, 'images/product/16/1699182184_La68S2SDtcauZ8B_.webp', 'images/product/16/1699182185_dLQwVD1yEGZvK4J_.webp', 1, 0, '2023-11-05 09:40:42', '2023-11-05 11:03:05', NULL),
(17, NULL, 3.00, NULL, 1000, 100, NULL, 'images/product/17/1699182259_YtuFIKHUtxTg40h_.webp', 'images/product/17/1699182259_peTtdULofHOryJX_.webp', 1, 0, '2023-11-05 09:41:08', '2023-11-05 11:04:19', NULL),
(18, NULL, 3.00, NULL, 1000, 100, NULL, 'images/product/18/1699182310_VAWevM0BfgdZE8l_.webp', 'images/product/18/1699182310_LEUHThoCycbWhkn_.webp', 1, 0, '2023-11-05 09:41:23', '2023-11-05 11:05:10', NULL),
(19, NULL, 5.00, NULL, 1000, 100, NULL, 'images/product/19/1699183125_tQ8rOdZPRZaz9DC_.webp', 'images/product/19/1699183126_pZimDCVKr9Bo2Zo_.webp', 1, 0, '2023-11-05 09:41:57', '2023-11-05 11:18:46', NULL),
(20, NULL, 3.00, NULL, 1000, 100, NULL, 'images/product/20/1699182415_8UIw4s8Z10F3rZX_.webp', 'images/product/20/1699182416_xsGFfG4CI2Ko6t7_.webp', 1, 0, '2023-11-05 11:06:55', '2023-11-05 11:07:55', NULL),
(21, NULL, 3.00, NULL, 1000, 100, NULL, 'images/product/21/1699182432_Z5z8GlzvPfUmpB1_.webp', 'images/product/21/1699182433_R5njzdAtI4OBg2D_.webp', 1, 0, '2023-11-05 11:07:12', '2023-11-05 11:07:41', NULL),
(22, NULL, 7.00, NULL, 1000, 1000, NULL, 'images/product/22/1699184089_Ipy8Zksop6DAsoN_.webp', 'images/product/22/1699184089_VWePnLyPO7p9wKz_.webp', 1, 0, '2023-11-05 11:34:49', '2023-11-05 11:34:49', NULL),
(23, NULL, 7.00, NULL, 1000, 1000, NULL, 'images/product/23/1699184476_T5TRrn3Og5CE2pq_.webp', 'images/product/23/1699184476_Xn32vmLH1VGSYi4_.webp', 1, 0, '2023-11-05 11:41:16', '2023-11-05 11:41:17', NULL),
(24, NULL, 42.00, NULL, 1000, 1000, NULL, 'images/product/24/1699184944_WMIs3dm63Wx2DVV_.webp', 'images/product/24/1699184945_IDAb99ufuyE3ayf_.webp', 1, 0, '2023-11-05 11:49:04', '2023-11-05 11:49:05', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `product_photos`
--

CREATE TABLE `product_photos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_extension` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_size` int(11) DEFAULT NULL,
  `file_h` int(11) DEFAULT NULL,
  `file_w` int(11) DEFAULT NULL,
  `position` int(11) NOT NULL DEFAULT 0,
  `is_default` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product_translations`
--

CREATE TABLE `product_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `des` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_des` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_translations`
--

INSERT INTO `product_translations` (`id`, `product_id`, `locale`, `slug`, `name`, `des`, `g_title`, `g_des`) VALUES
(1, 1, 'ar', 'نصف-دجاجة-شواية', 'نصف دجاجة شواية', NULL, NULL, NULL),
(2, 2, 'ar', 'نصف-دجاجة-على-الفحم', 'نصف دجاجة على الفحم', NULL, NULL, NULL),
(3, 3, 'ar', 'حبة-دجاج-عالشواية-مع-الرز', 'حبة دجاج عالشواية مع الرز', NULL, NULL, NULL),
(4, 4, 'ar', 'خضار-مدخن', 'خضار مدخن', NULL, NULL, NULL),
(5, 5, 'ar', 'بامية', 'بامية', NULL, NULL, NULL),
(6, 6, 'ar', 'ملوخية', 'ملوخية', NULL, NULL, NULL),
(7, 7, 'ar', 'أرز-بخارى', 'أرز بخارى', NULL, NULL, NULL),
(8, 8, 'ar', 'أرز-ابيض', 'أرز ابيض', NULL, NULL, NULL),
(9, 9, 'ar', 'أرز-أحمر', 'أرز أحمر', NULL, NULL, NULL),
(10, 10, 'ar', 'سلطة-خضراء', 'سلطة خضراء', NULL, NULL, NULL),
(11, 11, 'ar', 'سلطة-جرجير', 'سلطة جرجير', NULL, NULL, NULL),
(12, 12, 'ar', 'سلطة-لبن-بالخيار', 'سلطة لبن بالخيار', NULL, NULL, NULL),
(13, 13, 'ar', 'سطلة-حارة', 'سطلة حارة', NULL, NULL, NULL),
(14, 14, 'ar', 'سطلة-طحينة', 'سطلة طحينة', NULL, NULL, NULL),
(15, 15, 'ar', 'سطلة-زبادى', 'سطلة زبادى', 'سطلة زبادى', NULL, NULL),
(16, 16, 'ar', 'لبن', 'لبن', NULL, NULL, NULL),
(17, 17, 'ar', 'مشروبات-غازية', 'سفن اب دايت', NULL, NULL, NULL),
(18, 18, 'ar', 'سفن-اب', 'سفن اب', NULL, NULL, NULL),
(19, 19, 'ar', 'مهلبية', 'مهلبية', NULL, NULL, NULL),
(20, 20, 'ar', 'بيبسي', 'بيبسي', NULL, NULL, NULL),
(21, 21, 'ar', 'ديو', 'ديو', NULL, NULL, NULL),
(22, 22, 'ar', 'مكرونة-باشميل', 'مكرونة باشميل', NULL, NULL, NULL),
(23, 23, 'ar', 'أرز-مصري', 'أرز مصري', NULL, NULL, NULL),
(24, 24, 'ar', 'حبة-دجاج-على-الفحم-مع-الرز', 'حبة دجاج على الفحم مع الرز', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_ar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `name_ar`, `name_en`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'ادمن كامل الصلاحيات', 'Full Admin Permission ', 'web', '2023-10-06 11:39:21', '2023-10-06 11:39:21'),
(2, 'WebEditor', 'محرر  الموقع', 'محرر  الموقع', 'web', '2023-10-06 11:39:22', '2023-10-06 11:41:04'),
(3, 'ShopEditor', 'محرر المتجر', 'محرر المتجر', 'web', '2023-10-06 11:41:34', '2023-10-06 11:41:34'),
(4, 'Orders', 'ادارة الطلبات', 'ادارة الطلبات', 'web', '2023-10-06 11:42:04', '2023-10-06 11:42:04'),
(5, 'WebConfig', 'ادارة اعدادت الموقع', 'ادارة اعدادت الموقع', 'web', '2023-10-06 11:43:12', '2023-10-06 11:43:12'),
(6, 'UsersEditor', 'ادارة المستخدمين', 'ادارة المستخدمين', 'web', '2023-10-06 11:44:17', '2023-10-06 11:44:17'),
(7, 'CustomerEditor', 'ادارة العملاء', 'ادارة العملاء', 'web', '2023-10-06 11:45:12', '2023-10-06 11:45:12');

-- --------------------------------------------------------

--
-- Table structure for table `role_has_permissions`
--

CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_has_permissions`
--

INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 1),
(5, 1),
(6, 1),
(7, 1),
(8, 1),
(9, 1),
(10, 1),
(11, 1),
(12, 1),
(13, 1),
(14, 1),
(14, 2),
(15, 1),
(15, 2),
(16, 1),
(16, 2),
(17, 1),
(18, 1),
(19, 1),
(20, 1),
(20, 2),
(21, 1),
(21, 2),
(22, 1),
(22, 2),
(23, 1),
(24, 1),
(24, 2),
(25, 1),
(26, 1),
(26, 2),
(27, 1),
(28, 1),
(28, 2),
(29, 1),
(30, 1),
(31, 1),
(32, 1),
(32, 2),
(33, 1),
(34, 1),
(34, 2),
(35, 1),
(36, 1),
(37, 1),
(38, 1),
(38, 2),
(39, 1),
(39, 2),
(40, 1),
(40, 2),
(40, 3),
(41, 1),
(42, 1),
(43, 1),
(44, 1),
(44, 2),
(45, 1),
(45, 2),
(46, 1),
(46, 2),
(47, 1),
(48, 1),
(49, 1),
(49, 2),
(50, 1),
(50, 2),
(51, 1),
(51, 2),
(52, 1),
(52, 2),
(53, 1),
(53, 2),
(54, 1),
(54, 2),
(55, 1),
(55, 2),
(56, 1),
(56, 2),
(57, 1),
(58, 1),
(59, 1),
(59, 2),
(60, 1),
(60, 2),
(61, 1),
(61, 2),
(62, 1),
(62, 2),
(63, 1),
(64, 1),
(64, 2),
(65, 1),
(65, 2),
(66, 1),
(66, 2),
(67, 1),
(67, 2),
(68, 1),
(69, 1),
(70, 1),
(70, 3),
(71, 1),
(71, 3),
(72, 1),
(72, 3),
(73, 1),
(74, 1),
(75, 1),
(76, 1),
(76, 3),
(77, 1),
(77, 3),
(78, 1),
(78, 3),
(79, 1),
(80, 1),
(81, 1),
(82, 1),
(82, 7),
(83, 1),
(83, 7),
(84, 1),
(84, 7),
(85, 1),
(86, 1),
(87, 1),
(87, 4),
(88, 1),
(88, 4),
(89, 1),
(89, 4),
(90, 1),
(91, 1);

-- --------------------------------------------------------

--
-- Table structure for table `shopping_cart`
--

CREATE TABLE `shopping_cart` (
  `identifier` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `instance` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `shopping_orders`
--

CREATE TABLE `shopping_orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `customer_id` bigint(20) UNSIGNED NOT NULL,
  `address_id` bigint(20) UNSIGNED NOT NULL,
  `uuid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_date` datetime NOT NULL,
  `invoice_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `total` double(8,2) NOT NULL DEFAULT 0.00,
  `units` int(11) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `shopping_order_addresses`
--

CREATE TABLE `shopping_order_addresses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `recipient_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_option` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `shopping_order_logs`
--

CREATE TABLE `shopping_order_logs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `add_date` datetime NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `shopping_order_products`
--

CREATE TABLE `shopping_order_products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `product_ref` int(11) NOT NULL,
  `sku` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` double(8,2) NOT NULL,
  `sale_price` double(8,2) DEFAULT NULL,
  `qty` double(8,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `roles_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `phone`, `photo`, `photo_thum_1`, `roles_name`, `status`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Hany Darwish ', 'hany.freestyle4u@gmail.com', NULL, NULL, NULL, '[\"admin\"]', 1, NULL, '$2y$10$EStiO4vL.VXmDbSByRkMDuF5w5xMXfcTYl7CmXaLfFaM1HWpyFIjq', NULL, '2023-10-06 11:39:21', '2023-10-06 11:39:21'),
(2, 'ادارة الموقع', 'user1@etman-group.com', NULL, NULL, NULL, '[\"WebEditor\"]', 1, NULL, '$2y$10$h1u/qiUoz3ugsakqugSB4uTkFFjVHDTul/kuZFXc9eQq3xsJIiiW6', NULL, '2023-10-06 11:39:22', '2023-10-06 12:00:51'),
(3, 'ادارة المتجر', 'user2@etman-group.com', NULL, NULL, NULL, '[\"ShopEditor\",\"Orders\",\"CustomerEditor\"]', 1, NULL, '$2y$10$mHVaciHskWCa88oK6nPgR.FdAw/nCuYu8uO9KGmwWgntvM4.YfwL6', NULL, '2023-10-06 11:39:22', '2023-10-06 14:08:20'),
(4, 'ادارة الطلبات', 'user3@etman-group.com', NULL, NULL, NULL, '[\"Orders\",\"CustomerEditor\"]', 1, NULL, '$2y$10$0kN0y42eGh9NmczfzKy40OtmzNSA8xwnTYz3IVg1JJHy6jGfaVkxO', NULL, '2023-10-06 11:58:52', '2023-10-06 14:07:48');

-- --------------------------------------------------------

--
-- Table structure for table `users_customers`
--

CREATE TABLE `users_customers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `whatsapp` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `land_phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city_id` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_temp` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users_customers`
--

INSERT INTO `users_customers` (`id`, `name`, `company_name`, `email`, `phone`, `whatsapp`, `land_phone`, `city_id`, `status`, `is_active`, `photo`, `photo_thum_1`, `email_verified_at`, `password`, `password_temp`, `last_login`, `remember_token`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'احمد الشيخ', NULL, 'ahmed@gmail.com', '554064063', NULL, NULL, 3, 1, 1, NULL, NULL, NULL, '$2y$10$EdpwmFdQE7xn2NMV76qxje9tjL/7J4kDqTQ2qVMcQaB.kxgNuBnNu', NULL, '2023-11-05 16:44:08', NULL, '2023-11-05 14:44:08', '2023-11-05 14:45:53', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users_customers_addresses`
--

CREATE TABLE `users_customers_addresses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city_id` bigint(20) UNSIGNED NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `recipient_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_option` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users_customers_addresses`
--

INSERT INTO `users_customers_addresses` (`id`, `uuid`, `customer_id`, `name`, `city_id`, `address`, `recipient_name`, `phone`, `phone_option`, `is_default`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, '97af70df-3647-4365-95bf-6f1595b16a21', 1, 'العنوان الافتراضى', 3, '6945 البحر المتوسط، العقيق\r\nالرياض 13515‎', 'احمد الشيخ', '554064063', NULL, 1, NULL, '2023-11-05 14:46:40', '2023-11-05 14:46:40');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `app_menus`
--
ALTER TABLE `app_menus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_menu_translations`
--
ALTER TABLE `app_menu_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `app_menu_translations_menu_id_locale_unique` (`menu_id`,`locale`),
  ADD KEY `app_menu_translations_locale_index` (`locale`);

--
-- Indexes for table `app_settings`
--
ALTER TABLE `app_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `branches`
--
ALTER TABLE `branches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `branch_translations`
--
ALTER TABLE `branch_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `branch_translations_branch_id_locale_unique` (`branch_id`,`locale`),
  ADD KEY `branch_translations_locale_index` (`locale`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `categories_parent_id_foreign` (`parent_id`);

--
-- Indexes for table `category_product`
--
ALTER TABLE `category_product`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_product_category_id_foreign` (`category_id`),
  ADD KEY `category_product_product_id_foreign` (`product_id`);

--
-- Indexes for table `category_translations`
--
ALTER TABLE `category_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `category_translations_category_id_locale_unique` (`category_id`,`locale`),
  ADD UNIQUE KEY `category_translations_locale_slug_unique` (`locale`,`slug`),
  ADD KEY `category_translations_locale_index` (`locale`);

--
-- Indexes for table `config_def_photos`
--
ALTER TABLE `config_def_photos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `config_settings`
--
ALTER TABLE `config_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `config_setting_translations`
--
ALTER TABLE `config_setting_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `config_setting_translations_setting_id_locale_unique` (`setting_id`,`locale`),
  ADD KEY `config_setting_translations_locale_index` (`locale`);

--
-- Indexes for table `config_upload_filters`
--
ALTER TABLE `config_upload_filters`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `config_upload_filter_sizes`
--
ALTER TABLE `config_upload_filter_sizes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `config_upload_filter_sizes_filter_id_foreign` (`filter_id`);

--
-- Indexes for table `config_web_privacies`
--
ALTER TABLE `config_web_privacies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `config_web_privacy_translations`
--
ALTER TABLE `config_web_privacy_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `config_web_privacy_translations_privacy_id_locale_unique` (`privacy_id`,`locale`),
  ADD KEY `config_web_privacy_translations_locale_index` (`locale`);

--
-- Indexes for table `contact_us_forms`
--
ALTER TABLE `contact_us_forms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `data_cities`
--
ALTER TABLE `data_cities`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `data_cities_name_unique` (`name`),
  ADD UNIQUE KEY `data_cities_name_en_unique` (`name_en`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  ADD KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  ADD KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `news_letters`
--
ALTER TABLE `news_letters`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `news_letters_email_unique` (`email`);

--
-- Indexes for table `opening_hours`
--
ALTER TABLE `opening_hours`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `pages_cat_id_unique` (`cat_id`);

--
-- Indexes for table `page_translations`
--
ALTER TABLE `page_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `page_translations_page_id_locale_unique` (`page_id`,`locale`),
  ADD UNIQUE KEY `page_translations_locale_slug_unique` (`locale`,`slug`),
  ADD KEY `page_translations_locale_index` (`locale`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_photos`
--
ALTER TABLE `product_photos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_photos_product_id_foreign` (`product_id`);

--
-- Indexes for table `product_translations`
--
ALTER TABLE `product_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `product_translations_product_id_locale_unique` (`product_id`,`locale`),
  ADD UNIQUE KEY `product_translations_locale_slug_unique` (`locale`,`slug`),
  ADD KEY `product_translations_locale_index` (`locale`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`);

--
-- Indexes for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `role_has_permissions_role_id_foreign` (`role_id`);

--
-- Indexes for table `shopping_cart`
--
ALTER TABLE `shopping_cart`
  ADD PRIMARY KEY (`identifier`,`instance`);

--
-- Indexes for table `shopping_orders`
--
ALTER TABLE `shopping_orders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `shopping_orders_uuid_unique` (`uuid`),
  ADD KEY `shopping_orders_customer_id_foreign` (`customer_id`),
  ADD KEY `shopping_orders_address_id_foreign` (`address_id`);

--
-- Indexes for table `shopping_order_addresses`
--
ALTER TABLE `shopping_order_addresses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shopping_order_logs`
--
ALTER TABLE `shopping_order_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `shopping_order_logs_order_id_foreign` (`order_id`);

--
-- Indexes for table `shopping_order_products`
--
ALTER TABLE `shopping_order_products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `shopping_order_products_order_id_foreign` (`order_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `users_customers`
--
ALTER TABLE `users_customers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_customers_phone_unique` (`phone`),
  ADD UNIQUE KEY `users_customers_email_unique` (`email`);

--
-- Indexes for table `users_customers_addresses`
--
ALTER TABLE `users_customers_addresses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_customers_addresses_uuid_unique` (`uuid`),
  ADD KEY `users_customers_addresses_customer_id_foreign` (`customer_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `app_menus`
--
ALTER TABLE `app_menus`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `app_menu_translations`
--
ALTER TABLE `app_menu_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `app_settings`
--
ALTER TABLE `app_settings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `branches`
--
ALTER TABLE `branches`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `branch_translations`
--
ALTER TABLE `branch_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `category_product`
--
ALTER TABLE `category_product`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `category_translations`
--
ALTER TABLE `category_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `config_def_photos`
--
ALTER TABLE `config_def_photos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `config_settings`
--
ALTER TABLE `config_settings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `config_setting_translations`
--
ALTER TABLE `config_setting_translations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `config_upload_filters`
--
ALTER TABLE `config_upload_filters`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `config_upload_filter_sizes`
--
ALTER TABLE `config_upload_filter_sizes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `config_web_privacies`
--
ALTER TABLE `config_web_privacies`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `config_web_privacy_translations`
--
ALTER TABLE `config_web_privacy_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `contact_us_forms`
--
ALTER TABLE `contact_us_forms`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `data_cities`
--
ALTER TABLE `data_cities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=625;

--
-- AUTO_INCREMENT for table `news_letters`
--
ALTER TABLE `news_letters`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `opening_hours`
--
ALTER TABLE `opening_hours`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `page_translations`
--
ALTER TABLE `page_translations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=92;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `product_photos`
--
ALTER TABLE `product_photos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product_translations`
--
ALTER TABLE `product_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `shopping_orders`
--
ALTER TABLE `shopping_orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `shopping_order_addresses`
--
ALTER TABLE `shopping_order_addresses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `shopping_order_logs`
--
ALTER TABLE `shopping_order_logs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `shopping_order_products`
--
ALTER TABLE `shopping_order_products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users_customers`
--
ALTER TABLE `users_customers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users_customers_addresses`
--
ALTER TABLE `users_customers_addresses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `app_menu_translations`
--
ALTER TABLE `app_menu_translations`
  ADD CONSTRAINT `app_menu_translations_menu_id_foreign` FOREIGN KEY (`menu_id`) REFERENCES `app_menus` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `branch_translations`
--
ALTER TABLE `branch_translations`
  ADD CONSTRAINT `branch_translations_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `categories`
--
ALTER TABLE `categories`
  ADD CONSTRAINT `categories_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `categories` (`id`);

--
-- Constraints for table `category_product`
--
ALTER TABLE `category_product`
  ADD CONSTRAINT `category_product_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `category_product_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `category_translations`
--
ALTER TABLE `category_translations`
  ADD CONSTRAINT `category_translations_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `config_setting_translations`
--
ALTER TABLE `config_setting_translations`
  ADD CONSTRAINT `config_setting_translations_setting_id_foreign` FOREIGN KEY (`setting_id`) REFERENCES `config_settings` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `config_upload_filter_sizes`
--
ALTER TABLE `config_upload_filter_sizes`
  ADD CONSTRAINT `config_upload_filter_sizes_filter_id_foreign` FOREIGN KEY (`filter_id`) REFERENCES `config_upload_filters` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `config_web_privacy_translations`
--
ALTER TABLE `config_web_privacy_translations`
  ADD CONSTRAINT `config_web_privacy_translations_privacy_id_foreign` FOREIGN KEY (`privacy_id`) REFERENCES `config_web_privacies` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `page_translations`
--
ALTER TABLE `page_translations`
  ADD CONSTRAINT `page_translations_page_id_foreign` FOREIGN KEY (`page_id`) REFERENCES `pages` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `product_photos`
--
ALTER TABLE `product_photos`
  ADD CONSTRAINT `product_photos_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `product_translations`
--
ALTER TABLE `product_translations`
  ADD CONSTRAINT `product_translations_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `shopping_orders`
--
ALTER TABLE `shopping_orders`
  ADD CONSTRAINT `shopping_orders_address_id_foreign` FOREIGN KEY (`address_id`) REFERENCES `shopping_order_addresses` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `shopping_orders_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `users_customers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `shopping_order_logs`
--
ALTER TABLE `shopping_order_logs`
  ADD CONSTRAINT `shopping_order_logs_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `shopping_orders` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `shopping_order_products`
--
ALTER TABLE `shopping_order_products`
  ADD CONSTRAINT `shopping_order_products_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `shopping_orders` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `users_customers_addresses`
--
ALTER TABLE `users_customers_addresses`
  ADD CONSTRAINT `users_customers_addresses_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `users_customers` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
